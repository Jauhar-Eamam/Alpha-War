"""
AGENTS WAR - your trading agent.  This is the ONLY code file you submit.

How to work:
  1. Choose TRAIN_WINDOW: the block of days your agent learns from. It can be ANY block of
     at most 10 years (2520 days) inside days 0..3707, e.g. (0, 2519), (252, 2771), (1188, 3707).
  2. train(data) is called ONCE with only those days. Learn your parameters / fit your models there.
  3. Write every trading idea as its own function named  decide_<something>(history).
     decide only sees the last year of prices, so all long-term learning must happen in train().
  4. python compare.py          -> tests all your decide_ ideas side by side
     python compare.py windows  -> tests your final agent trained on 6 different 10-year windows
  5. Point  decide  (bottom of this file) at the one you want us to run on the secret period.

Rules for this file:
  * TRAIN_WINDOW, train (optional) and decide must exist with these names.
  * A TRAIN_WINDOW longer than 2520 days is rejected (disqualified).
  * Allowed imports: python standard library, numpy, pandas, scikit-learn.
  * No internet, no reading other files, no hard-coded prices or day numbers in decide,
    and no collecting prices day by day inside decide to get around the 1-year limit.
  * On average your agent must keep at least 30% of the money invested.
  * A full run (training + secret days) must finish within 3 minutes.

The four ideas in this file
  A. decide_risk_parity_trend : long-only, trending stocks, inverse-volatility weights,
                                total exposure shrinks when the market gets turbulent.
  B. decide_momentum_quality  : 6-month momentum winners (skipping the last week), smooth-risk
                                weighted, market-trend switch between full and defensive exposure.
  C. decide_dip_in_uptrend    : buy short-term dips, but only in stocks whose long trend is up.
  D. decide_ridge_ranker      : a Ridge model fitted in train() ranks stocks from 9 features;
                                holds the top-ranked ones, risk-scaled by market volatility.
"""
import numpy as np
import pandas as pd

TEAM_NAME = "<Your team name here>"
TRAIN_WINDOW = (756, 3275)    # (first_day, last_day) your agent learns from - at most 2520 days
MODEL = {}                    # whatever train() learns is stored here

# data / history: dict with keys "open", "high", "low", "close", "volume".
#          Each one is a pandas DataFrame: rows = days (last row = today),
#          columns = stocks (STOCK_01 ... STOCK_12).
# decide returns: dict {stock: weight}
#          weight =  0.25 -> put 25% of your money in that stock (buy)
#          weight = -0.10 -> bet 10% against that stock (short sell)
#          stocks you leave out get 0; whatever is unused stays in cash.
#          The sum of |weights| must be <= 1 (scaled down for you if it is more).

MIN_EXPOSURE = 0.45           # never go below this (the rule needs >= 30% on average)
STEP = 0.05                   # weights are rounded to 5% buckets -> far fewer tiny, costly trades
FEATURES = ["ret5", "ret20", "ret60", "ret120", "vol20", "vol60", "dist_ma50", "dist_high", "range10"]


# ----------------------------------------------------------------------------- helpers
def _bucket(weights):
    """Round weights to STEP buckets so small daily wiggles do not cost trading fees."""
    out = {}
    for s, w in weights.items():
        w = round(float(w) / STEP) * STEP
        if abs(w) > 1e-9:
            out[s] = w
    return out


def _market_vol(close, days=40):
    """Annualised volatility of an equal-weight basket over the last `days` days."""
    basket = close.pct_change().iloc[-days:].mean(axis=1)
    return float(basket.std() * np.sqrt(252))


def _exposure(close, floor=MIN_EXPOSURE):
    """Invest less when the market is more turbulent than usual (target learnt in train)."""
    target = MODEL.get("target_vol", 0.18)
    vol = _market_vol(close)
    return float(np.clip(target / vol, floor, 1.0)) if vol > 0 else 1.0


def _market_uptrend(close, days=100):
    basket = (1 + close.pct_change().fillna(0).mean(axis=1)).cumprod()
    return bool(basket.iloc[-1] > basket.iloc[-days:].mean())


def _inverse_vol(close, picks, exposure, days=60):
    vol = close.pct_change().iloc[-days:].std()[picks].replace(0, np.nan).dropna()
    inv = 1 / vol
    return {s: exposure * inv[s] / inv.sum() for s in inv.index}


def _gated_inverse_vol(close, gate, exposure, days=60):
    """Weights proportional to gate/volatility (gate between 0 and 1 = how much we like the stock).
    A smooth gate means a stock fades in and out slowly instead of flipping 0 <-> full."""
    vol = close.pct_change().iloc[-days:].std().replace(0, np.nan)
    raw = (gate / vol).fillna(0.0).clip(lower=0.0)
    if raw.sum() <= 0:
        return None
    return {s: exposure * raw[s] / raw.sum() for s in raw.index}


def _low_vol_fallback(close, exposure):
    vol = close.pct_change().iloc[-60:].std()
    return _inverse_vol(close, list(vol.nsmallest(4).index), exposure)


def _features(close, high, low, volume):
    """9 features for every stock and day (vectorised). The last row is 'today'."""
    r = close.pct_change()
    f = {
        "ret5": close.pct_change(5),
        "ret20": close.pct_change(20),
        "ret60": close.pct_change(60),
        "ret120": close.pct_change(120),
        "vol20": r.rolling(20).std(),
        "vol60": r.rolling(60).std(),
        "dist_ma50": close / close.rolling(50).mean() - 1,
        "dist_high": close / close.rolling(120, min_periods=60).max() - 1,
        "range10": ((high - low) / close).rolling(10).mean(),
    }
    return f


def _zscore_rows(df):
    """Compare stocks with each other on the same day (cross-section z-score)."""
    return df.sub(df.mean(axis=1), axis=0).div(df.std(axis=1).replace(0, np.nan), axis=0)


# ----------------------------------------------------------------------------- training
def train(data):
    """Called once, with ONLY the days in TRAIN_WINDOW."""
    close = data["close"]
    returns = close.pct_change()
    basket = returns.mean(axis=1)

    # 1) volatility target for the exposure rule: a typical calm-market volatility of the basket
    rolling_vol = basket.rolling(40).std() * np.sqrt(252)
    MODEL["target_vol"] = float(rolling_vol.quantile(0.5))

    # 2) best moving-average length for the trend filters
    next_day = returns.shift(-1)
    best_sharpe, best_days = -np.inf, 100
    for days in [50, 100, 150, 200]:
        hold = close > close.rolling(days).mean()
        daily = (next_day * hold).sum(axis=1) / hold.sum(axis=1).replace(0, np.nan)
        sharpe = daily.mean() / daily.std()
        if sharpe > best_sharpe:
            best_sharpe, best_days = sharpe, days
    MODEL["ma_days"] = best_days

    # 3) Ridge model: features today -> next-5-day return (ranked among stocks)
    from sklearn.linear_model import Ridge
    feats = _features(close, data["high"], data["low"], data["volume"])
    z = {k: _zscore_rows(v) for k, v in feats.items()}
    fwd = _zscore_rows(close.pct_change(20).shift(-20))     # slower 20-day target -> steadier ranking, fewer trades
    X = np.stack([z[k].to_numpy().ravel() for k in FEATURES], axis=1)
    y = fwd.to_numpy().ravel()
    ok = np.isfinite(X).all(axis=1) & np.isfinite(y)
    model = Ridge(alpha=5000.0).fit(X[ok], y[ok])       # strong shrinkage: noise is the enemy
    MODEL["ridge_coef"] = model.coef_
    MODEL["ridge_intercept"] = float(model.intercept_)


# ----------------------------------------------------------------------------- idea A
def decide_risk_parity_trend(history):
    """A. Hold every stock in an uptrend, weighted by 1/volatility; shrink exposure when turbulent."""
    close = history["close"]
    days = MODEL.get("ma_days", 100)
    if len(close) < max(days, 61):
        return _bucket({s: MIN_EXPOSURE / close.shape[1] for s in close.columns})
    gap = close.iloc[-1] / close.iloc[-days:].mean() - 1          # how far above its average
    gate = (0.5 + gap / 0.10).clip(0, 1)                          # full at +5%, zero at -5%: smooth switch
    exposure = _exposure(close)
    w = _gated_inverse_vol(close, gate, exposure)
    if w is None:                                    # whole market in a downtrend: lowest-risk stocks, floor exposure
        w = _low_vol_fallback(close, MIN_EXPOSURE)
    return _bucket(w)


# ----------------------------------------------------------------------------- idea B
def decide_momentum_quality(history):
    """B. Top-5 stocks by 6-month momentum (skip last week), steady risers, market-trend switch."""
    close = history["close"]
    if len(close) < 130:
        return _bucket({s: MIN_EXPOSURE / close.shape[1] for s in close.columns})
    momentum = close.iloc[-6] / close.iloc[-126] - 1           # skip the most recent week (short-term reversal)
    smooth = close.pct_change().iloc[-126:].std()              # reward steady gains, not lottery tickets
    score = (momentum / smooth).where(momentum > 0, -np.inf)
    rank = score.rank(pct=True)                                # 1.0 = best stock today
    gate = ((rank - 0.4) / 0.6).clip(0, 1)                     # best 60% get weight, fading in smoothly
    exposure = 1.0 if _market_uptrend(close, MODEL.get("ma_days", 100)) else 0.6
    w = _gated_inverse_vol(close, gate, exposure)
    if w is None:
        w = _low_vol_fallback(close, MIN_EXPOSURE)
    return _bucket(w)


# ----------------------------------------------------------------------------- idea C
def decide_dip_in_uptrend(history):
    """C. Buy stocks that dipped over the last week, but only if their long trend is still up."""
    close = history["close"]
    if len(close) < 101:
        return _bucket({s: MIN_EXPOSURE / close.shape[1] for s in close.columns})
    r = close.pct_change()
    uptrend = close.iloc[-1] > close.iloc[-100:].mean()
    fortnight = close.iloc[-1] / close.iloc[-11] - 1            # 10-day move: slower, less noisy than 5 days
    z = fortnight / (r.iloc[-60:].std() * np.sqrt(10))          # how unusual was that move
    exposure = _exposure(close)
    gap = close.iloc[-1] / close.iloc[-100:].mean() - 1
    trend_gate = (0.5 + gap / 0.10).clip(0, 1)                  # core holding: smooth trend gate
    dip_gate = (-z / 2).clip(0, 1) * (trend_gate > 0.5)         # extra tilt toward stocks on a dip, smooth
    core = _gated_inverse_vol(close, trend_gate, 0.6 * exposure)
    tilt = _gated_inverse_vol(close, dip_gate, 0.4 * exposure)
    if core is None:
        return _bucket(_low_vol_fallback(close, MIN_EXPOSURE))
    if tilt is None:                                            # no dips today: keep the core only, scaled up
        tilt = {s: 0.4 * exposure * core[s] / (0.6 * exposure) for s in core}
    return _bucket({s: core.get(s, 0.0) + tilt.get(s, 0.0) for s in close.columns})


# ----------------------------------------------------------------------------- idea D
def decide_ridge_ranker(history):
    """D. Ridge model (fitted in train) scores each stock; hold the 5 best, risk-scaled."""
    close = history["close"]
    if "ridge_coef" not in MODEL or len(close) < 121:
        return _bucket({s: MIN_EXPOSURE / close.shape[1] for s in close.columns})
    feats = _features(close, history["high"], history["low"], history["volume"])
    X = np.stack([_zscore_rows(feats[k]).iloc[-1].to_numpy() for k in FEATURES], axis=1)
    X = np.nan_to_num(X)
    score = pd.Series(X @ MODEL["ridge_coef"] + MODEL["ridge_intercept"], index=close.columns)
    gate = (0.5 + score / (2 * score.std() + 1e-9)).clip(0, 1)     # smooth: positive scores fade in
    w = _gated_inverse_vol(close, gate, _exposure(close, floor=0.6))
    return _bucket(w) if w else _bucket(_low_vol_fallback(close, MIN_EXPOSURE))


# ----------------------------------------------------------------------------- blend of A and D
def decide_blend_rp_ridge(history):
    """Blend: half idea A (steady, low-drawdown) + half idea D (higher-return model)."""
    a = decide_risk_parity_trend(history)
    d = decide_ridge_ranker(history)
    return _bucket({s: 0.5 * a.get(s, 0.0) + 0.5 * d.get(s, 0.0) for s in set(a) | set(d)})


decide = decide_blend_rp_ridge         # <- the agent we will run on the secret period


if __name__ == "__main__":
    # python strategy.py -> trains on TRAIN_WINDOW and prints the performance metrics.
    # (Only runs when you start this file yourself; our evaluation just imports it.)
    import sys
    from pathlib import Path
    import engine

    data = engine.load(Path(__file__).resolve().parent / "data" / "train.csv")
    window = engine.train_agent(sys.modules[__name__], data)
    log = engine.backtest(decide, data, verbose=False)["log"]
    inside = (log.index >= window[0]) & (log.index <= window[1])
    print(f"{TEAM_NAME}: trained on days {window[0]}-{window[1]}")
    print("\nInside the training window:")
    engine.print_metrics(engine.metrics(log[inside]))
    print("Outside the training window (validation):")
    engine.print_metrics(engine.metrics(log[~inside]))
